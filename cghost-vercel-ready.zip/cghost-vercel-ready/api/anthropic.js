export async function POST(request) {
  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return Response.json(
        { error: 'Falta configurar ANTHROPIC_API_KEY en Vercel.' },
        { status: 500 }
      );
    }

    const body = await request.json();
    const { model, max_tokens, system, messages } = body || {};

    if (!model || !max_tokens || !Array.isArray(messages)) {
      return Response.json(
        { error: 'Solicitud inválida.' },
        { status: 400 }
      );
    }

    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({ model, max_tokens, system, messages })
    });

    const text = await upstream.text();

    return new Response(text, {
      status: upstream.status,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return Response.json(
      { error: 'Error interno del servidor.', detail: String(error) },
      { status: 500 }
    );
  }
}
