# CG Host Pro — despliegue en Vercel

## Estructura
- `index.html`: app principal
- `api/anthropic.js`: función serverless para proteger la API key
- `.gitignore`

## Subida a GitHub
```bash
git init
git add .
git commit -m "Deploy inicial"
git branch -M main
git remote add origin https://github.com/TU-USUARIO/TU-REPO.git
git push -u origin main
```

## Configuración en Vercel
1. En Vercel, pulsa **Import Project**.
2. Conecta GitHub y elige el repo.
3. Framework Preset: **Other**.
4. Build Command: vacío.
5. Output Directory: `.`
6. Deploy.

## Variable de entorno obligatoria
En Vercel -> Project -> Settings -> Environment Variables:
- Key: `ANTHROPIC_API_KEY`
- Value: tu clave real

Luego redeploy.

## Nota importante
Esta versión evita exponer la API key en el navegador.
